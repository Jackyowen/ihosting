<?php
/**
 * The template for displaying the footer shop.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package iHosting
 */

get_footer();