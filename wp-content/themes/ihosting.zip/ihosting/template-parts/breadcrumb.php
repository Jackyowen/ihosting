<?php
/**
 * Template part for displaying breadcrumb .
 *
 * @package iHosting
 */

?>

<?php echo ihosting_breadcrumb(); ?>


