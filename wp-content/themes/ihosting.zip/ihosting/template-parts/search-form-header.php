<?php

// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) {
	exit;
}

global $ihosting;

?>

<div id="ts-search-head" class="ts-search-head fullheight just-hidden" >
	<div class="ts-serch-inner">
		<?php get_search_form(); ?>
	</div>
</div>
