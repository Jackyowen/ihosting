<?php

// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
* footer-soon.php
* Footer Coming Soon
* @author Theme Studio
* @package IHOSTING
* @since 1.0.0
*/
?>
    
    
</div>
<!-- End / Site main -->
<?php wp_footer(); ?>
</body>
</html>