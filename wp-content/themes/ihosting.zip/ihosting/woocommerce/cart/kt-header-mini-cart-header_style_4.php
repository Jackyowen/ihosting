<?php
/**
 * Mini Cart For Header Style: style_4
 *
 * @author  Gordon Freeman
 * @version 1.0
 */

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

// The same structure with Header style_2
wc_get_template( 'cart/kt-header-mini-cart-header_style_2.php' );