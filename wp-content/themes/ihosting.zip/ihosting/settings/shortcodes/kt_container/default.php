<?php
/*
Name:   Default layout
Slug:   default
*/
return  array(
	array(
        'type'  => 'dropdown',
        'value' => array(
			__( 'Default (Max width 1790px)', 'mazano' )   => 'container-wapper',
            __( 'Full (Max width 1570px)', 'mazano' )            => 'container-wapper-1570',
			__( 'Conatiner (Max width 1170px)', 'mazano' ) => 'container',
			__( 'Full (Width 100%)', 'mazano' )            => 'container-full'
        ),
        'std'         => 'container-wapper',
        'heading'     => __( 'Navigation', 'ihosting' ),
        'param_name'  => 'default_content_width',
        "dependency"  => array(
            "element" => "layout",
            "value" => array('default')
        ),
        'admin_label' => false,
    ),

);
