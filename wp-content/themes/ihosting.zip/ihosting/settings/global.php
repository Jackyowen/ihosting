<?php
$kutetheme_ovic_option_key = "supermarket_kt_options";