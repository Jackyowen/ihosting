<div class="<?php echo esc_attr($elementClass) ; ?> <?php echo esc_attr($this->shortcode) ; ?> <?php echo esc_attr($layout) ?>"  >
    <div class="<?php echo esc_attr( $default_content_width );?>">    	<?php echo wpb_js_remove_wpautop( $content ); ?>
    </div>
</div>