<?php
global $kutetheme_ovic_toolkit;
$uniqid = uniqid('kt_container');
$atts = $this->getAttributes( $atts );
$elementClass = $this->getCustomClass( $atts );
extract( $atts );
if(isset($atts['layout']) && $atts['layout']){
    include get_template_directory().'/vc_templates/'.$this->shortcode.'/'.$atts['layout'].'.php';
}